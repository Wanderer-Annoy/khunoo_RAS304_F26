LED SILKSCREEN FIX

D1 and D2 5 mm LED footprint body-outline graphics were removed from F.SilkS because JLCDFM reported the circular/arc silkscreen too close to the LED through-hole pads.

Preserved:
- D1/D2 reference text
- electrical pads and nets
- drill holes
- F.Fab body outline
- F.CrtYd courtyard
- 3D models
- schematic and all copper routing

Regenerate Gerbers and drill files before re-uploading to JLCDFM.
