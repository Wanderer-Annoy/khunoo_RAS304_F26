D3 LED SILKSCREEN FIX

- Removed only D3 footprint F.SilkS body-outline graphic primitives that can violate silkscreen-to-pad clearance.
- D3 reference text remains on F.SilkS.
- D3 pads, drill holes, nets, copper routing, courtyard, fabrication graphics, 3D model, and schematic were not changed.
- Existing D1/D2 fixes in the uploaded project were preserved.

Regenerate Gerbers and drill files before uploading to JLCDFM. Old Gerber files in this archive predate this D3 edit.
