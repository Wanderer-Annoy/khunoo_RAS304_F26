DataCollectionBoard v1.3 - JLCDFM silkscreen fix

Changes:
- Enabled "Subtract soldermask from silkscreen" in Gerber plot settings.
  This clips silkscreen away from exposed pads in generated Gerbers and addresses JLCDFM silkscreen-to-pad overlap/clearance flags.
- Increased narrow 0.12 mm silkscreen graphic strokes to 0.20 mm where applicable, targeting JLCDFM silkscreen line-width warnings.
- Copper routing was intentionally left unchanged because the JLCDFM screenshot shows the 64 trace-width checks in the green/good column.
- Annular-ring findings shown by JLCDFM are warnings; they were not blindly enlarged because changing through-hole pad geometry without component mechanical dimensions can create fit/clearance problems.

Next:
1. Open the project in KiCad.
2. PCB Editor -> press B -> save.
3. File -> Fabrication Outputs -> Gerbers.
4. Confirm "Subtract soldermask from silkscreen" is checked.
5. Plot fresh Gerbers and regenerate drill files.
6. ZIP only the fresh Gerber/drill output and upload that ZIP to JLCDFM.
