Data Collection Board v1.3 - clean KiCad project

Included:
- DataCollectionBoard v1.3.kicad_pcb  (newest PCB)
- DataCollectionBoard v1.3.kicad_sch  (matching editable schematic)
- DataCollectionBoard v1.3.kicad_pro  (KiCad project)
- DataCollectionBoard v1.3.kicad_prl  (local project settings)
- fp-lib-table
- DRC_v1.2_before_v1.3_fix.rpt

Change from uploaded v1.2:
- Removed the accidental F.Cu graphic perimeter rectangle (UUID 5070df9a-35cb-4b88-9333-e8081ff228da) that caused the 0.400 mm copper-to-edge DRC violation.
- The uploaded DRC already reported 0 unconnected pads and 0 footprint errors.
- The Curiosity Nano footprint library mismatch warning may remain because fp-lib-table points to the original Windows local footprint library path. The PCB itself contains the placed footprint.

Open DataCollectionBoard v1.3.kicad_pro in KiCad. In PCB Editor press B to refill zones, then run Inspect > Design Rules Checker.

PASS 3 FIX (2026-11-21)
- Removed stray F.Cu rectangle from (20.5, 21.0) to (120.0, 120.5) that caused 0.400 mm copper-to-edge clearance violation.
- Preserved Edge.Cuts rectangle from (20.0, 20.5) to (120.0, 120.5), maintaining the 100 x 100 mm board outline.
- Latest supplied DRC had 0 unconnected pads and 0 footprint errors.
- Remaining Curiosity Nano library mismatch is a local-library synchronization warning, not an electrical connectivity error.
